<?php

return [
    'enabled' => env('DEVFORGE_ENABLED', false),

    'agents_enabled' => env('DEVFORGE_AGENTS_ENABLED', false),

    /*
    |--------------------------------------------------------------------------
    | Livewire to DevForge migration matrix
    |--------------------------------------------------------------------------
    |
    | Every domain can be migrated independently. The legacy and DevForge
    | paths are intentionally explicit so changes on either side are reviewed
    | as contract changes rather than inferred from route names.
    |
    */
    'domains' => [
        'authentication' => [
            'enabled' => env('DEVFORGE_AUTHENTICATION_ENABLED', false),
            'routes' => [
                'auth.force-password-reset' => ['legacy' => '/force-password-reset', 'devforge' => '/force-password-reset'],
                'verify.email' => ['legacy' => '/verify', 'devforge' => '/verify'],
            ],
        ],
        'dashboard' => [
            'enabled' => env('DEVFORGE_DASHBOARD_ENABLED', false),
            'routes' => [
                'dashboard' => ['legacy' => '/', 'devforge' => '/'],
                'admin.index' => ['legacy' => '/admin', 'devforge' => '/admin'],
                'onboarding' => ['legacy' => '/onboarding', 'devforge' => '/onboarding'],
            ],
        ],
        'subscription' => [
            'enabled' => env('DEVFORGE_SUBSCRIPTION_ENABLED', false),
            'routes' => [
                'subscription.show' => ['legacy' => '/subscription', 'devforge' => '/subscription'],
                'subscription.index' => ['legacy' => '/subscription/new', 'devforge' => '/subscription/new'],
            ],
        ],
        'settings' => [
            'enabled' => env('DEVFORGE_SETTINGS_ENABLED', false),
            'routes' => [
                'settings.index' => ['legacy' => '/settings', 'devforge' => '/settings'],
                'settings.advanced' => ['legacy' => '/settings/advanced', 'devforge' => '/settings/advanced'],
                'settings.updates' => ['legacy' => '/settings/updates', 'devforge' => '/settings/updates'],
                'settings.backup' => ['legacy' => '/settings/backup', 'devforge' => '/settings/backup'],
                'settings.email' => ['legacy' => '/settings/email', 'devforge' => '/settings/email'],
                'settings.oauth' => ['legacy' => '/settings/oauth', 'devforge' => '/settings/oauth'],
                'settings.scheduled-jobs' => ['legacy' => '/settings/scheduled-jobs', 'devforge' => '/settings/scheduled-jobs'],
            ],
        ],
        'profile' => [
            'enabled' => env('DEVFORGE_PROFILE_ENABLED', false),
            'routes' => [
                'profile' => ['legacy' => '/profile', 'devforge' => '/profile'],
                'profile.appearance' => ['legacy' => '/profile/appearance', 'devforge' => '/profile/appearance'],
            ],
        ],
        'tags' => [
            'enabled' => env('DEVFORGE_TAGS_ENABLED', false),
            'routes' => [
                'tags.show' => ['legacy' => '/tags/{tagName?}', 'devforge' => '/tags/{tagName?}'],
            ],
        ],
        'notifications' => [
            'enabled' => env('DEVFORGE_NOTIFICATIONS_ENABLED', false),
            'routes' => [
                'notifications.email' => ['legacy' => '/notifications/email', 'devforge' => '/notifications/email'],
                'notifications.telegram' => ['legacy' => '/notifications/telegram', 'devforge' => '/notifications/telegram'],
                'notifications.discord' => ['legacy' => '/notifications/discord', 'devforge' => '/notifications/discord'],
                'notifications.slack' => ['legacy' => '/notifications/slack', 'devforge' => '/notifications/slack'],
                'notifications.pushover' => ['legacy' => '/notifications/pushover', 'devforge' => '/notifications/pushover'],
                'notifications.webhook' => ['legacy' => '/notifications/webhook', 'devforge' => '/notifications/webhook'],
            ],
        ],
        'storage' => [
            'enabled' => env('DEVFORGE_STORAGE_ENABLED', false),
            'routes' => [
                'storage.index' => ['legacy' => '/storages', 'devforge' => '/storages'],
                'storage.show' => ['legacy' => '/storages/{storage_uuid}', 'devforge' => '/storages/{storage_uuid}'],
                'storage.resources' => ['legacy' => '/storages/{storage_uuid}/resources', 'devforge' => '/storages/{storage_uuid}/resources'],
            ],
        ],
        'shared-variables' => [
            'enabled' => env('DEVFORGE_SHARED_VARIABLES_ENABLED', false),
            'routes' => [
                'shared-variables.index' => ['legacy' => '/shared-variables', 'devforge' => '/shared-variables'],
                'shared-variables.team.index' => ['legacy' => '/shared-variables/team', 'devforge' => '/shared-variables/team'],
                'shared-variables.project.index' => ['legacy' => '/shared-variables/projects', 'devforge' => '/shared-variables/projects'],
                'shared-variables.project.show' => ['legacy' => '/shared-variables/project/{project_uuid}', 'devforge' => '/shared-variables/project/{project_uuid}'],
                'shared-variables.environment.index' => ['legacy' => '/shared-variables/environments', 'devforge' => '/shared-variables/environments'],
                'shared-variables.environment.show' => ['legacy' => '/shared-variables/environments/project/{project_uuid}/environment/{environment_uuid}', 'devforge' => '/shared-variables/environments/project/{project_uuid}/environment/{environment_uuid}'],
                'shared-variables.server.index' => ['legacy' => '/shared-variables/servers', 'devforge' => '/shared-variables/servers'],
                'shared-variables.server.show' => ['legacy' => '/shared-variables/server/{server_uuid}', 'devforge' => '/shared-variables/server/{server_uuid}'],
            ],
        ],
        'team' => [
            'enabled' => env('DEVFORGE_TEAM_ENABLED', false),
            'routes' => [
                'team.index' => ['legacy' => '/team', 'devforge' => '/team'],
                'team.member.index' => ['legacy' => '/team/members', 'devforge' => '/team/members'],
                'team.admin-view' => ['legacy' => '/team/admin', 'devforge' => '/team/admin'],
                'team.invitation.show' => ['legacy' => '/invitations/{uuid}', 'devforge' => '/invitations/{uuid}'],
            ],
        ],
        'terminal' => [
            'enabled' => env('DEVFORGE_TERMINAL_ENABLED', false),
            'routes' => [
                'terminal' => ['legacy' => '/terminal', 'devforge' => '/terminal'],
            ],
        ],
        'projects' => [
            'enabled' => env('DEVFORGE_PROJECTS_ENABLED', false),
            'routes' => [
                'project.index' => ['legacy' => '/projects', 'devforge' => '/projects'],
                'project.show' => ['legacy' => '/project/{project_uuid}', 'devforge' => '/project/{project_uuid}'],
                'project.edit' => ['legacy' => '/project/{project_uuid}/edit', 'devforge' => '/project/{project_uuid}/edit'],
                'project.resource.index' => ['legacy' => '/project/{project_uuid}/environment/{environment_uuid}', 'devforge' => '/project/{project_uuid}/environment/{environment_uuid}'],
                'project.clone-me' => ['legacy' => '/project/{project_uuid}/environment/{environment_uuid}/clone', 'devforge' => '/project/{project_uuid}/environment/{environment_uuid}/clone'],
                'project.resource.create' => ['legacy' => '/project/{project_uuid}/environment/{environment_uuid}/new', 'devforge' => '/project/{project_uuid}/environment/{environment_uuid}/new'],
                'project.environment.edit' => ['legacy' => '/project/{project_uuid}/environment/{environment_uuid}/edit', 'devforge' => '/project/{project_uuid}/environment/{environment_uuid}/edit'],
            ],
        ],
        'applications' => [
            'enabled' => env('DEVFORGE_APPLICATIONS_ENABLED', false),
            'routes' => [
                'project.application.configuration' => ['legacy' => '/project/{project_uuid}/environment/{environment_uuid}/application/{application_uuid}', 'devforge' => '/project/{project_uuid}/environment/{environment_uuid}/application/{application_uuid}'],
                'project.application.swarm' => ['legacy' => '/project/{project_uuid}/environment/{environment_uuid}/application/{application_uuid}/swarm', 'devforge' => '/project/{project_uuid}/environment/{environment_uuid}/application/{application_uuid}/swarm'],
                'project.application.advanced' => ['legacy' => '/project/{project_uuid}/environment/{environment_uuid}/application/{application_uuid}/advanced', 'devforge' => '/project/{project_uuid}/environment/{environment_uuid}/application/{application_uuid}/advanced'],
                'project.application.environment-variables' => ['legacy' => '/project/{project_uuid}/environment/{environment_uuid}/application/{application_uuid}/environment-variables', 'devforge' => '/project/{project_uuid}/environment/{environment_uuid}/application/{application_uuid}/environment-variables'],
                'project.application.persistent-storage' => ['legacy' => '/project/{project_uuid}/environment/{environment_uuid}/application/{application_uuid}/persistent-storage', 'devforge' => '/project/{project_uuid}/environment/{environment_uuid}/application/{application_uuid}/persistent-storage'],
                'project.application.source' => ['legacy' => '/project/{project_uuid}/environment/{environment_uuid}/application/{application_uuid}/source', 'devforge' => '/project/{project_uuid}/environment/{environment_uuid}/application/{application_uuid}/source'],
                'project.application.servers' => ['legacy' => '/project/{project_uuid}/environment/{environment_uuid}/application/{application_uuid}/servers', 'devforge' => '/project/{project_uuid}/environment/{environment_uuid}/application/{application_uuid}/servers'],
                'project.application.scheduled-tasks.show' => ['legacy' => '/project/{project_uuid}/environment/{environment_uuid}/application/{application_uuid}/scheduled-tasks', 'devforge' => '/project/{project_uuid}/environment/{environment_uuid}/application/{application_uuid}/scheduled-tasks'],
                'project.application.webhooks' => ['legacy' => '/project/{project_uuid}/environment/{environment_uuid}/application/{application_uuid}/webhooks', 'devforge' => '/project/{project_uuid}/environment/{environment_uuid}/application/{application_uuid}/webhooks'],
                'project.application.preview-deployments' => ['legacy' => '/project/{project_uuid}/environment/{environment_uuid}/application/{application_uuid}/preview-deployments', 'devforge' => '/project/{project_uuid}/environment/{environment_uuid}/application/{application_uuid}/preview-deployments'],
                'project.application.healthcheck' => ['legacy' => '/project/{project_uuid}/environment/{environment_uuid}/application/{application_uuid}/healthcheck', 'devforge' => '/project/{project_uuid}/environment/{environment_uuid}/application/{application_uuid}/healthcheck'],
                'project.application.rollback' => ['legacy' => '/project/{project_uuid}/environment/{environment_uuid}/application/{application_uuid}/rollback', 'devforge' => '/project/{project_uuid}/environment/{environment_uuid}/application/{application_uuid}/rollback'],
                'project.application.resource-limits' => ['legacy' => '/project/{project_uuid}/environment/{environment_uuid}/application/{application_uuid}/resource-limits', 'devforge' => '/project/{project_uuid}/environment/{environment_uuid}/application/{application_uuid}/resource-limits'],
                'project.application.resource-operations' => ['legacy' => '/project/{project_uuid}/environment/{environment_uuid}/application/{application_uuid}/resource-operations', 'devforge' => '/project/{project_uuid}/environment/{environment_uuid}/application/{application_uuid}/resource-operations'],
                'project.application.metrics' => ['legacy' => '/project/{project_uuid}/environment/{environment_uuid}/application/{application_uuid}/metrics', 'devforge' => '/project/{project_uuid}/environment/{environment_uuid}/application/{application_uuid}/metrics'],
                'project.application.tags' => ['legacy' => '/project/{project_uuid}/environment/{environment_uuid}/application/{application_uuid}/tags', 'devforge' => '/project/{project_uuid}/environment/{environment_uuid}/application/{application_uuid}/tags'],
                'project.application.danger' => ['legacy' => '/project/{project_uuid}/environment/{environment_uuid}/application/{application_uuid}/danger', 'devforge' => '/project/{project_uuid}/environment/{environment_uuid}/application/{application_uuid}/danger'],
                'project.application.deployment.index' => ['legacy' => '/project/{project_uuid}/environment/{environment_uuid}/application/{application_uuid}/deployment', 'devforge' => '/project/{project_uuid}/environment/{environment_uuid}/application/{application_uuid}/deployment'],
                'project.application.deployment.show' => ['legacy' => '/project/{project_uuid}/environment/{environment_uuid}/application/{application_uuid}/deployment/{deployment_uuid}', 'devforge' => '/project/{project_uuid}/environment/{environment_uuid}/application/{application_uuid}/deployment/{deployment_uuid}'],
                'project.application.logs' => ['legacy' => '/project/{project_uuid}/environment/{environment_uuid}/application/{application_uuid}/logs', 'devforge' => '/project/{project_uuid}/environment/{environment_uuid}/application/{application_uuid}/logs'],
                'project.application.command' => ['legacy' => '/project/{project_uuid}/environment/{environment_uuid}/application/{application_uuid}/terminal', 'devforge' => '/project/{project_uuid}/environment/{environment_uuid}/application/{application_uuid}/terminal'],
                'project.application.scheduled-tasks' => ['legacy' => '/project/{project_uuid}/environment/{environment_uuid}/application/{application_uuid}/tasks/{task_uuid}', 'devforge' => '/project/{project_uuid}/environment/{environment_uuid}/application/{application_uuid}/tasks/{task_uuid}'],
            ],
        ],
        'databases' => [
            'enabled' => env('DEVFORGE_DATABASES_ENABLED', false),
            'routes' => [
                'project.database.configuration' => ['legacy' => '/project/{project_uuid}/environment/{environment_uuid}/database/{database_uuid}', 'devforge' => '/project/{project_uuid}/environment/{environment_uuid}/database/{database_uuid}'],
                'project.database.environment-variables' => ['legacy' => '/project/{project_uuid}/environment/{environment_uuid}/database/{database_uuid}/environment-variables', 'devforge' => '/project/{project_uuid}/environment/{environment_uuid}/database/{database_uuid}/environment-variables'],
                'project.database.servers' => ['legacy' => '/project/{project_uuid}/environment/{environment_uuid}/database/{database_uuid}/servers', 'devforge' => '/project/{project_uuid}/environment/{environment_uuid}/database/{database_uuid}/servers'],
                'project.database.import-backup' => ['legacy' => '/project/{project_uuid}/environment/{environment_uuid}/database/{database_uuid}/import-backup', 'devforge' => '/project/{project_uuid}/environment/{environment_uuid}/database/{database_uuid}/import-backup'],
                'project.database.persistent-storage' => ['legacy' => '/project/{project_uuid}/environment/{environment_uuid}/database/{database_uuid}/persistent-storage', 'devforge' => '/project/{project_uuid}/environment/{environment_uuid}/database/{database_uuid}/persistent-storage'],
                'project.database.healthcheck' => ['legacy' => '/project/{project_uuid}/environment/{environment_uuid}/database/{database_uuid}/healthcheck', 'devforge' => '/project/{project_uuid}/environment/{environment_uuid}/database/{database_uuid}/healthcheck'],
                'project.database.webhooks' => ['legacy' => '/project/{project_uuid}/environment/{environment_uuid}/database/{database_uuid}/webhooks', 'devforge' => '/project/{project_uuid}/environment/{environment_uuid}/database/{database_uuid}/webhooks'],
                'project.database.resource-limits' => ['legacy' => '/project/{project_uuid}/environment/{environment_uuid}/database/{database_uuid}/resource-limits', 'devforge' => '/project/{project_uuid}/environment/{environment_uuid}/database/{database_uuid}/resource-limits'],
                'project.database.resource-operations' => ['legacy' => '/project/{project_uuid}/environment/{environment_uuid}/database/{database_uuid}/resource-operations', 'devforge' => '/project/{project_uuid}/environment/{environment_uuid}/database/{database_uuid}/resource-operations'],
                'project.database.metrics' => ['legacy' => '/project/{project_uuid}/environment/{environment_uuid}/database/{database_uuid}/metrics', 'devforge' => '/project/{project_uuid}/environment/{environment_uuid}/database/{database_uuid}/metrics'],
                'project.database.tags' => ['legacy' => '/project/{project_uuid}/environment/{environment_uuid}/database/{database_uuid}/tags', 'devforge' => '/project/{project_uuid}/environment/{environment_uuid}/database/{database_uuid}/tags'],
                'project.database.danger' => ['legacy' => '/project/{project_uuid}/environment/{environment_uuid}/database/{database_uuid}/danger', 'devforge' => '/project/{project_uuid}/environment/{environment_uuid}/database/{database_uuid}/danger'],
                'project.database.logs' => ['legacy' => '/project/{project_uuid}/environment/{environment_uuid}/database/{database_uuid}/logs', 'devforge' => '/project/{project_uuid}/environment/{environment_uuid}/database/{database_uuid}/logs'],
                'project.database.command' => ['legacy' => '/project/{project_uuid}/environment/{environment_uuid}/database/{database_uuid}/terminal', 'devforge' => '/project/{project_uuid}/environment/{environment_uuid}/database/{database_uuid}/terminal'],
                'project.database.backup.index' => ['legacy' => '/project/{project_uuid}/environment/{environment_uuid}/database/{database_uuid}/backups', 'devforge' => '/project/{project_uuid}/environment/{environment_uuid}/database/{database_uuid}/backups'],
                'project.database.backup.execution' => ['legacy' => '/project/{project_uuid}/environment/{environment_uuid}/database/{database_uuid}/backups/{backup_uuid}', 'devforge' => '/project/{project_uuid}/environment/{environment_uuid}/database/{database_uuid}/backups/{backup_uuid}'],
            ],
        ],
        'services' => [
            'enabled' => env('DEVFORGE_SERVICES_ENABLED', false),
            'routes' => [
                'project.service.configuration' => ['legacy' => '/project/{project_uuid}/environment/{environment_uuid}/service/{service_uuid}', 'devforge' => '/project/{project_uuid}/environment/{environment_uuid}/service/{service_uuid}'],
                'project.service.logs' => ['legacy' => '/project/{project_uuid}/environment/{environment_uuid}/service/{service_uuid}/logs', 'devforge' => '/project/{project_uuid}/environment/{environment_uuid}/service/{service_uuid}/logs'],
                'project.service.environment-variables' => ['legacy' => '/project/{project_uuid}/environment/{environment_uuid}/service/{service_uuid}/environment-variables', 'devforge' => '/project/{project_uuid}/environment/{environment_uuid}/service/{service_uuid}/environment-variables'],
                'project.service.storages' => ['legacy' => '/project/{project_uuid}/environment/{environment_uuid}/service/{service_uuid}/storages', 'devforge' => '/project/{project_uuid}/environment/{environment_uuid}/service/{service_uuid}/storages'],
                'project.service.scheduled-tasks.show' => ['legacy' => '/project/{project_uuid}/environment/{environment_uuid}/service/{service_uuid}/scheduled-tasks', 'devforge' => '/project/{project_uuid}/environment/{environment_uuid}/service/{service_uuid}/scheduled-tasks'],
                'project.service.webhooks' => ['legacy' => '/project/{project_uuid}/environment/{environment_uuid}/service/{service_uuid}/webhooks', 'devforge' => '/project/{project_uuid}/environment/{environment_uuid}/service/{service_uuid}/webhooks'],
                'project.service.resource-operations' => ['legacy' => '/project/{project_uuid}/environment/{environment_uuid}/service/{service_uuid}/resource-operations', 'devforge' => '/project/{project_uuid}/environment/{environment_uuid}/service/{service_uuid}/resource-operations'],
                'project.service.tags' => ['legacy' => '/project/{project_uuid}/environment/{environment_uuid}/service/{service_uuid}/tags', 'devforge' => '/project/{project_uuid}/environment/{environment_uuid}/service/{service_uuid}/tags'],
                'project.service.danger' => ['legacy' => '/project/{project_uuid}/environment/{environment_uuid}/service/{service_uuid}/danger', 'devforge' => '/project/{project_uuid}/environment/{environment_uuid}/service/{service_uuid}/danger'],
                'project.service.command' => ['legacy' => '/project/{project_uuid}/environment/{environment_uuid}/service/{service_uuid}/terminal', 'devforge' => '/project/{project_uuid}/environment/{environment_uuid}/service/{service_uuid}/terminal'],
                'project.service.database.backups' => ['legacy' => '/project/{project_uuid}/environment/{environment_uuid}/service/{service_uuid}/{stack_service_uuid}/backups', 'devforge' => '/project/{project_uuid}/environment/{environment_uuid}/service/{service_uuid}/{stack_service_uuid}/backups'],
                'project.service.database.import' => ['legacy' => '/project/{project_uuid}/environment/{environment_uuid}/service/{service_uuid}/{stack_service_uuid}/import', 'devforge' => '/project/{project_uuid}/environment/{environment_uuid}/service/{service_uuid}/{stack_service_uuid}/import'],
                'project.service.index.advanced' => ['legacy' => '/project/{project_uuid}/environment/{environment_uuid}/service/{service_uuid}/{stack_service_uuid}/advanced', 'devforge' => '/project/{project_uuid}/environment/{environment_uuid}/service/{service_uuid}/{stack_service_uuid}/advanced'],
                'project.service.index' => ['legacy' => '/project/{project_uuid}/environment/{environment_uuid}/service/{service_uuid}/{stack_service_uuid}', 'devforge' => '/project/{project_uuid}/environment/{environment_uuid}/service/{service_uuid}/{stack_service_uuid}'],
                'project.service.scheduled-tasks' => ['legacy' => '/project/{project_uuid}/environment/{environment_uuid}/service/{service_uuid}/tasks/{task_uuid}', 'devforge' => '/project/{project_uuid}/environment/{environment_uuid}/service/{service_uuid}/tasks/{task_uuid}'],
            ],
        ],
        'servers' => [
            'enabled' => env('DEVFORGE_SERVERS_ENABLED', false),
            'routes' => [
                'server.index' => ['legacy' => '/servers', 'devforge' => '/servers'],
                'server.show' => ['legacy' => '/server/{server_uuid}', 'devforge' => '/server/{server_uuid}'],
                'server.advanced' => ['legacy' => '/server/{server_uuid}/advanced', 'devforge' => '/server/{server_uuid}/advanced'],
                'server.swarm' => ['legacy' => '/server/{server_uuid}/swarm', 'devforge' => '/server/{server_uuid}/swarm'],
                'server.sentinel' => ['legacy' => '/server/{server_uuid}/sentinel', 'devforge' => '/server/{server_uuid}/sentinel'],
                'server.sentinel.logs' => ['legacy' => '/server/{server_uuid}/sentinel/logs', 'devforge' => '/server/{server_uuid}/sentinel/logs'],
                'server.private-key' => ['legacy' => '/server/{server_uuid}/private-key', 'devforge' => '/server/{server_uuid}/private-key'],
                'server.cloud-provider-token' => ['legacy' => '/server/{server_uuid}/cloud-provider-token', 'devforge' => '/server/{server_uuid}/cloud-provider-token'],
                'server.ca-certificate' => ['legacy' => '/server/{server_uuid}/ca-certificate', 'devforge' => '/server/{server_uuid}/ca-certificate'],
                'server.resources' => ['legacy' => '/server/{server_uuid}/resources', 'devforge' => '/server/{server_uuid}/resources'],
                'server.cloudflare-tunnel' => ['legacy' => '/server/{server_uuid}/cloudflare-tunnel', 'devforge' => '/server/{server_uuid}/cloudflare-tunnel'],
                'server.destinations' => ['legacy' => '/server/{server_uuid}/destinations', 'devforge' => '/server/{server_uuid}/destinations'],
                'server.log-drains' => ['legacy' => '/server/{server_uuid}/log-drains', 'devforge' => '/server/{server_uuid}/log-drains'],
                'server.metrics' => ['legacy' => '/server/{server_uuid}/metrics', 'devforge' => '/server/{server_uuid}/metrics'],
                'server.delete' => ['legacy' => '/server/{server_uuid}/danger', 'devforge' => '/server/{server_uuid}/danger'],
                'server.proxy' => ['legacy' => '/server/{server_uuid}/proxy', 'devforge' => '/server/{server_uuid}/proxy'],
                'server.proxy.dynamic-confs' => ['legacy' => '/server/{server_uuid}/proxy/dynamic', 'devforge' => '/server/{server_uuid}/proxy/dynamic'],
                'server.proxy.logs' => ['legacy' => '/server/{server_uuid}/proxy/logs', 'devforge' => '/server/{server_uuid}/proxy/logs'],
                'server.command' => ['legacy' => '/server/{server_uuid}/terminal', 'devforge' => '/server/{server_uuid}/terminal'],
                'server.docker-cleanup' => ['legacy' => '/server/{server_uuid}/docker-cleanup', 'devforge' => '/server/{server_uuid}/docker-cleanup'],
                'server.security.patches' => ['legacy' => '/server/{server_uuid}/security/patches', 'devforge' => '/server/{server_uuid}/security/patches'],
                'server.security.terminal-access' => ['legacy' => '/server/{server_uuid}/security/terminal-access', 'devforge' => '/server/{server_uuid}/security/terminal-access'],
            ],
        ],
        'destinations' => [
            'enabled' => env('DEVFORGE_DESTINATIONS_ENABLED', false),
            'routes' => [
                'destination.index' => ['legacy' => '/destinations', 'devforge' => '/destinations'],
                'destination.show' => ['legacy' => '/destination/{destination_uuid}', 'devforge' => '/destination/{destination_uuid}'],
                'destination.resources' => ['legacy' => '/destination/{destination_uuid}/resources', 'devforge' => '/destination/{destination_uuid}/resources'],
            ],
        ],
        'security' => [
            'enabled' => env('DEVFORGE_SECURITY_ENABLED', false),
            'routes' => [
                'security.private-key.index' => ['legacy' => '/security/private-key', 'devforge' => '/security/private-key'],
                'security.private-key.show' => ['legacy' => '/security/private-key/{private_key_uuid}', 'devforge' => '/security/private-key/{private_key_uuid}'],
                'security.cloud-tokens' => ['legacy' => '/security/cloud-tokens', 'devforge' => '/security/cloud-tokens'],
                'security.cloud-init-scripts' => ['legacy' => '/security/cloud-init-scripts', 'devforge' => '/security/cloud-init-scripts'],
                'security.api-tokens' => ['legacy' => '/security/api-tokens', 'devforge' => '/security/api-tokens'],
            ],
        ],
        'sources' => [
            'enabled' => env('DEVFORGE_SOURCES_ENABLED', false),
            'routes' => [
                'source.all' => ['legacy' => '/sources', 'devforge' => '/sources'],
                'source.github.show' => ['legacy' => '/source/github/{github_app_uuid}', 'devforge' => '/source/github/{github_app_uuid}'],
                'source.github.permissions' => ['legacy' => '/source/github/{github_app_uuid}/permissions', 'devforge' => '/source/github/{github_app_uuid}/permissions'],
                'source.github.resources' => ['legacy' => '/source/github/{github_app_uuid}/resources', 'devforge' => '/source/github/{github_app_uuid}/resources'],
            ],
        ],
    ],
];
