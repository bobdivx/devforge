<?php

namespace App\Http\Controllers\DevForge\Core;

use App\Http\Controllers\Controller;
use App\Http\Requests\DevForge\Core\ResourceActionRequest;
use App\Models\Team;
use App\Models\User;
use App\Services\DevForge\Core\CoreResourceAction;
use App\Services\DevForge\Core\CoreResourceCatalog;
use App\Services\DevForge\Core\CoreResourcePresenter;
use App\Services\DevForge\Core\CurrentTeamContext;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class ResourceController extends Controller
{
    public function __construct(
        private readonly CurrentTeamContext $currentTeamContext,
        private readonly CoreResourceCatalog $catalog,
        private readonly CoreResourcePresenter $presenter,
        private readonly CoreResourceAction $resourceAction,
    ) {}

    public function catalog(Request $request): JsonResponse
    {
        $team = $this->currentTeam($request);
        $resources = $this->catalog->all($team)
            ->map(function (Model $resource): array {
                $this->authorize('view', $resource);

                return $this->presenter->present(
                    $resource,
                    (string) $resource->getAttribute('devforge_resource_type'),
                );
            })
            ->values();

        return response()->json([
            'data' => $resources,
            'meta' => [
                'count' => $resources->count(),
            ],
        ]);
    }

    public function index(Request $request, string $type): JsonResponse
    {
        $team = $this->currentTeam($request);
        $resources = $this->catalog->resources($team, $type)
            ->map(function (Model $resource) use ($type): array {
                $this->authorize('view', $resource);

                return $this->presenter->present($resource, $type);
            })
            ->values();

        return response()->json([
            'data' => $resources,
            'meta' => [
                'count' => $resources->count(),
                'resource_type' => str($type)->singular()->value(),
            ],
        ]);
    }

    public function show(Request $request, string $type, string $uuid): JsonResponse
    {
        $resource = $this->resource($request, $type, $uuid);
        $this->authorize('view', $resource);

        return response()->json([
            'data' => $this->presenter->present($resource, $type),
        ]);
    }

    public function configuration(Request $request): JsonResponse
    {
        $this->currentTeam($request);

        return response()->json([
            'data' => $this->presenter->configuration(),
        ]);
    }

    public function action(
        ResourceActionRequest $request,
        string $type,
        string $uuid,
        string $action,
    ): JsonResponse {
        $resource = $this->resource($request, $type, $uuid);
        $this->authorize($this->ability($type, $action), $resource);
        $options = $request->safe()->except('action');

        return response()->json([
            'data' => $this->resourceAction->execute($resource, $type, $action, $options),
        ], 202);
    }

    private function currentTeam(Request $request): Team
    {
        $user = $request->user();

        abort_unless($user instanceof User, 401, 'Unauthenticated.');

        return $this->currentTeamContext->resolve($user);
    }

    private function resource(Request $request, string $type, string $uuid): Model
    {
        $resource = $this->catalog->find($this->currentTeam($request), $type, $uuid);

        abort_unless($resource, 404, 'Resource not found.');

        return $resource;
    }

    private function ability(string $type, string $action): string
    {
        return match ($type) {
            'applications' => 'deploy',
            'services' => $action === 'stop' ? 'stop' : 'deploy',
            'databases' => 'manage',
            default => 'view',
        };
    }
}
