<?php

namespace App\Http\Controllers\DevForge;

use App\Http\Controllers\Controller;
use App\Jobs\Agent\RunAgentJob;
use App\Models\AiAgent;
use App\Models\AiProviderConfig;
use App\Models\AiProviderConfig;
use App\Models\Team;
use App\Models\User;
use App\Services\DevForge\Core\CurrentTeamContext;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class AgentController extends Controller
{
    public function __construct(private readonly CurrentTeamContext $currentTeamContext) {}

    public function index(Request $request): JsonResponse
    {
        $this->authorize('viewAny', AiAgent::class);
        $team = $this->currentTeam($request);

        $agents = AiAgent::query()
            ->where('team_id', $team->id)
            ->with(['providerConfig', 'runs' => fn ($q) => $q->latest()->limit(1)])
            ->orderBy('type')
            ->orderBy('name')
            ->get()
            ->map(fn (AiAgent $agent) => $this->present($agent));

        return response()->json([
            'data' => $agents,
            'meta' => ['count' => $agents->count()],
        ]);
    }

    public function store(Request $request): JsonResponse
    {
        $this->authorize('create', AiAgent::class);
        $team = $this->currentTeam($request);

        $validated = $request->validate([
            'type' => ['required', 'string', Rule::in(['debug', 'tech-watch', 'github', 'devforge', 'deployment', 'security'])],
            'name' => ['required', 'string', 'max:100'],
            'description' => ['nullable', 'string', 'max:500'],
            'avatar_color' => ['nullable', 'string', 'max:20'],
            'system_prompt' => ['nullable', 'string', 'max:5000'],
            'provider_config_id' => ['nullable', 'integer', Rule::exists('ai_provider_configs', 'id')->where('team_id', $team->id)],
            'parent_agent_id' => ['nullable', 'integer', Rule::exists('ai_agents', 'id')->where('team_id', $team->id)],
            'resource_uuid' => ['nullable', 'string', 'max:64'],
            'schedule_minutes' => ['nullable', 'integer', 'min:0'],
            'is_active' => ['nullable', 'boolean'],
        ]);

        if (empty($validated['provider_config_id'])) {
            $defaultProvider = AiProviderConfig::query()
                ->where('team_id', $team->id)
                ->where('is_default', true)
                ->first();

            if ($defaultProvider) {
                $validated['provider_config_id'] = $defaultProvider->id;
            }
        }

        $agent = AiAgent::create([
            'team_id' => $team->id,
            ...$validated,
        ]);

        return response()->json(['data' => $this->present($agent->load('providerConfig'))], 201);
    }

    public function show(Request $request, string $uuid): JsonResponse
    {
        $agent = $this->findAgent($request, $uuid);
        $this->authorize('view', $agent);

        return response()->json([
            'data' => $this->present($agent->load(['providerConfig', 'subAgents', 'runs' => fn ($q) => $q->latest()->limit(5)])),
        ]);
    }

    public function update(Request $request, string $uuid): JsonResponse
    {
        $team = $this->currentTeam($request);
        $agent = $this->findAgent($request, $uuid);
        $this->authorize('update', $agent);

        $validated = $request->validate([
            'name' => ['sometimes', 'string', 'max:100'],
            'description' => ['sometimes', 'nullable', 'string', 'max:500'],
            'avatar_color' => ['sometimes', 'nullable', 'string', 'max:20'],
            'system_prompt' => ['sometimes', 'nullable', 'string', 'max:5000'],
            'provider_config_id' => ['sometimes', 'nullable', 'integer', Rule::exists('ai_provider_configs', 'id')->where('team_id', $team->id)],
            'schedule_minutes' => ['sometimes', 'nullable', 'integer', 'min:0'],
            'is_active' => ['sometimes', 'boolean'],
            'status' => ['sometimes', 'string', Rule::in(['idle', 'paused'])],
        ]);

        $agent->update($validated);

        return response()->json(['data' => $this->present($agent->fresh(['providerConfig']))]);
    }

    public function destroy(Request $request, string $uuid): JsonResponse
    {
        $agent = $this->findAgent($request, $uuid);
        $this->authorize('delete', $agent);
        $agent->delete();

        return response()->json(['data' => ['deleted' => true]]);
    }

    public function run(Request $request, string $uuid): JsonResponse
    {
        $agent = $this->findAgent($request, $uuid);
        $this->authorize('run', $agent);

        abort_if($agent->status === 'running', 409, 'L\'agent est déjà en cours d\'exécution.');
        abort_if(! $agent->is_active, 422, 'L\'agent est inactif.');
        abort_if(! $agent->provider_config_id, 422, 'Aucun provider LLM configuré.');

        RunAgentJob::dispatch($agent, 'manual');

        return response()->json(['data' => ['queued' => true, 'agent_uuid' => $uuid]], 202);
    }

    private function currentTeam(Request $request): Team
    {
        $user = $request->user();
        abort_unless($user instanceof User, 401);

        return $this->currentTeamContext->resolve($user);
    }

    private function findAgent(Request $request, string $uuid): AiAgent
    {
        $team = $this->currentTeam($request);
        $agent = AiAgent::where('uuid', $uuid)->where('team_id', $team->id)->first();
        abort_unless($agent, 404, 'Agent introuvable.');

        return $agent;
    }

    /** @return array<string, mixed> */
    private function present(AiAgent $agent): array
    {
        $latestRun = $agent->relationLoaded('runs') ? $agent->runs->first() : null;

        return [
            'uuid' => $agent->uuid,
            'type' => $agent->type,
            'name' => $agent->name,
            'description' => $agent->description,
            'avatar_color' => $agent->avatar_color,
            'system_prompt' => $agent->system_prompt,
            'schedule_minutes' => $agent->schedule_minutes,
            'is_active' => $agent->is_active,
            'status' => $agent->status,
            'last_run_at' => $agent->last_run_at?->toISOString(),
            'provider' => $agent->providerConfig ? [
                'id' => $agent->providerConfig->id,
                'name' => $agent->providerConfig->name,
                'provider' => $agent->providerConfig->provider,
                'model' => $agent->providerConfig->model,
            ] : null,
            'parent_agent_id' => $agent->parent_agent_id,
            'resource_uuid' => $agent->resource_uuid,
            'sub_agents_count' => $agent->relationLoaded('subAgents') ? $agent->subAgents->count() : 0,
            'latest_run' => $latestRun ? [
                'uuid' => $latestRun->uuid,
                'status' => $latestRun->status,
                'summary' => $latestRun->summary,
                'trigger' => $latestRun->trigger,
                'created_at' => $latestRun->created_at->toISOString(),
            ] : null,
            'created_at' => $agent->created_at->toISOString(),
        ];
    }
}
