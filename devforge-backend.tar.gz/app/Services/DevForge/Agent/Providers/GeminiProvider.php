<?php

namespace App\Services\DevForge\Agent\Providers;

use App\Services\DevForge\Agent\Contracts\LlmProvider;
use App\Services\DevForge\Agent\Contracts\LlmResponse;
use Illuminate\Http\Client\ConnectionException;
use Illuminate\Support\Facades\Http;

class GeminiProvider implements LlmProvider
{
    private const BASE_URL = 'https://generativelanguage.googleapis.com/v1beta';

    public function __construct(
        private readonly string $apiKey,
        private readonly string $model = 'gemini-1.5-flash',
    ) {}

    /** {@inheritdoc} */
    public function chat(array $messages, array $tools = []): LlmResponse
    {
        $systemInstruction = collect($messages)
            ->firstWhere('role', 'system')['content'] ?? null;

        $contents = $this->formatMessages($messages);
        $payload = ['contents' => $contents];

        if (is_string($systemInstruction) && $systemInstruction !== '') {
            $payload['systemInstruction'] = [
                'parts' => [['text' => $systemInstruction]],
            ];
        }

        if (count($tools) > 0) {
            $payload['tools'] = [
                ['function_declarations' => array_map(fn ($t) => [
                    'name' => $t['name'],
                    'description' => $t['description'],
                    'parameters' => $t['parameters'],
                ], $tools)],
            ];
            $payload['tool_config'] = ['function_calling_config' => ['mode' => 'AUTO']];
        }

        $response = Http::withQueryParameters(['key' => $this->apiKey])
            ->timeout(60)
            ->post("{$this->baseUrl()}/models/{$this->model}:generateContent", $payload);

        if ($response->failed()) {
            throw new \RuntimeException("Gemini API error [{$response->status()}]: ".$response->body());
        }

        return $this->parseResponse($response->json());
    }

    public function testConnection(): bool
    {
        try {
            $response = Http::withQueryParameters(['key' => $this->apiKey])
                ->timeout(10)
                ->get("{$this->baseUrl()}/models");

            return $response->successful();
        } catch (ConnectionException) {
            return false;
        }
    }

    /**
     * @param  array<array{role: string, content: string|array<mixed>}>  $messages
     * @return array<mixed>
     */
    private function formatMessages(array $messages): array
    {
        return array_map(function (array $message): array {
            $role = $message['role'] === 'assistant' ? 'model' : 'user';
            $content = $message['content'];

            if (is_string($content)) {
                return ['role' => $role, 'parts' => [['text' => $content]]];
            }

            return ['role' => $role, 'parts' => $content];
        }, array_filter($messages, fn ($m) => $m['role'] !== 'system'));
    }

    /** @param array<mixed> $data */
    private function parseResponse(array $data): LlmResponse
    {
        $candidate = $data['candidates'][0] ?? [];
        $parts = $candidate['content']['parts'] ?? [];
        $finishReason = $candidate['finishReason'] ?? 'STOP';

        $text = '';
        $toolCalls = [];

        foreach ($parts as $part) {
            if (isset($part['text'])) {
                $text .= $part['text'];
            }
            if (isset($part['functionCall'])) {
                $toolCalls[] = [
                    'name' => $part['functionCall']['name'],
                    'arguments' => $part['functionCall']['args'] ?? [],
                ];
            }
        }

        $tokensUsed = ($data['usageMetadata']['totalTokenCount'] ?? 0);

        return new LlmResponse(
            text: $text,
            toolCalls: $toolCalls,
            tokensUsed: $tokensUsed,
            isFinished: in_array($finishReason, ['STOP', 'MAX_TOKENS'], true),
        );
    }

    private function baseUrl(): string
    {
        return self::BASE_URL;
    }
}
