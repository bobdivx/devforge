<?php

namespace App\Services\DevForge\Agent;

use App\Models\AiProviderConfig;
use App\Services\DevForge\Agent\Contracts\LlmProvider;
use App\Services\DevForge\Agent\Providers\GeminiProvider;
use App\Services\DevForge\Agent\Providers\OllamaProvider;

class LlmProviderFactory
{
    public function make(AiProviderConfig $config): LlmProvider
    {
        return match ($config->provider) {
            'gemini' => new GeminiProvider(
                apiKey: (string) $config->api_key,
                model: $config->model,
            ),
            'ollama' => new OllamaProvider(
                baseUrl: (string) $config->base_url,
                model: $config->model,
            ),
            default => throw new \InvalidArgumentException("Provider non supporté : {$config->provider}"),
        };
    }
}
