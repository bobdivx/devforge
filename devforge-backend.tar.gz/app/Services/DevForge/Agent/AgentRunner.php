<?php

namespace App\Services\DevForge\Agent;

use App\Events\AgentRunUpdated;
use App\Models\AiAgent;
use App\Models\AiAgentRun;
use App\Services\DevForge\Agent\Contracts\LlmResponse;
use App\Services\DevForge\Core\CoreResourceAction;
use App\Services\DevForge\Core\CoreResourceCatalog;
use App\Services\DevForge\DeploymentData;

class AgentRunner
{
    private const MAX_ITERATIONS = 10;

    /** @var array<array{role: string, content: string}> */
    private array $messages = [];

    public function __construct(
        private readonly LlmProviderFactory $providerFactory,
        private readonly CoreResourceCatalog $catalog,
        private readonly CoreResourceAction $resourceAction,
        private readonly DeploymentData $deploymentData,
    ) {}

    public function run(AiAgent $agent, AiAgentRun $run): void
    {
        $providerConfig = $agent->providerConfig;

        if (! $providerConfig) {
            $run->update([
                'status' => 'failed',
                'summary' => 'Aucun provider LLM configuré pour cet agent.',
                'finished_at' => now(),
            ]);
            $agent->update(['status' => 'error']);

            return;
        }

        $provider = $this->providerFactory->make($providerConfig);
        $toolkit = new AgentToolkit(
            team: $agent->team,
            run: $run,
            catalog: $this->catalog,
            resourceAction: $this->resourceAction,
            deploymentData: $this->deploymentData,
            assignedResourceUuid: $agent->resource_uuid,
        );

        $this->messages = [
            ['role' => 'system', 'content' => $this->buildSystemPrompt($agent)],
            ['role' => 'user', 'content' => $this->buildInitialContext($agent)],
        ];

        $run->update(['status' => 'running', 'started_at' => now()]);
        $run->appendLog('Agent démarré — provider: '.$providerConfig->provider.' / '.$providerConfig->model);

        $toolDefinitions = $toolkit->definitions();
        $iterations = 0;
        $summary = '';

        try {
            while ($iterations < self::MAX_ITERATIONS) {
                $iterations++;
                $run->appendLog("Itération #{$iterations}...");

                broadcast(new AgentRunUpdated($agent, $run, "Itération #{$iterations}"));

                /** @var LlmResponse $response */
                $response = $provider->chat($this->messages, $toolDefinitions);

                $run->update([
                    'tokens_used' => $run->tokens_used + $response->tokensUsed,
                    'iterations' => $iterations,
                ]);

                if ($response->text) {
                    $run->appendLog("Raisonnement: {$response->text}");
                    $summary = $response->text;
                }

                if (! $response->hasToolCalls()) {
                    $run->appendLog('Agent terminé — aucun appel d\'outil supplémentaire.');
                    break;
                }

                $toolResults = [];
                foreach ($response->toolCalls as $toolCall) {
                    $result = $toolkit->execute($toolCall['name'], $toolCall['arguments']);
                    $toolResults[] = [
                        'name' => $toolCall['name'],
                        'result' => $result,
                    ];
                }

                $this->messages[] = ['role' => 'assistant', 'content' => $response->text ?: 'Appel d\'outil.'];
                $this->messages[] = [
                    'role' => 'user',
                    'content' => 'Résultats des outils : '.json_encode($toolResults),
                ];

                if ($response->isFinished) {
                    break;
                }
            }

            if ($iterations >= self::MAX_ITERATIONS) {
                $run->appendLog('Limite d\'itérations atteinte.');
                $summary = $summary ?: 'Limite d\'itérations atteinte sans conclusion.';
            }

            $run->update([
                'status' => 'completed',
                'summary' => mb_substr($summary, 0, 1000),
                'finished_at' => now(),
            ]);

            $agent->update(['status' => 'idle', 'last_run_at' => now()]);
            broadcast(new AgentRunUpdated($agent, $run, 'completed'));

        } catch (\Throwable $e) {
            $run->appendLog('Erreur: '.$e->getMessage());
            $run->update([
                'status' => 'failed',
                'summary' => 'Erreur: '.mb_substr($e->getMessage(), 0, 500),
                'finished_at' => now(),
            ]);
            $agent->update(['status' => 'error', 'last_run_at' => now()]);
            broadcast(new AgentRunUpdated($agent, $run, 'failed'));
        }
    }

    private function buildSystemPrompt(AiAgent $agent): string
    {
        $basePrompt = $agent->system_prompt ?: $this->defaultSystemPrompt($agent->type);

        return <<<PROMPT
        {$basePrompt}

        Tu es un agent IA autonome intégré dans Coolify/DevForge, une plateforme PaaS auto-hébergée.
        Tu as accès à des outils pour surveiller et gérer les ressources de l'équipe.

        Règles importantes :
        - Sois proactif mais prudent : analyse d'abord, agis ensuite.
        - Documente chaque action avec l'outil send_notification.
        - N'arrête une application que si c'est absolument nécessaire.
        - Termine ta mission avec un résumé clair de ce que tu as trouvé et fait.
        - Réponds en français.
        PROMPT;
    }

    private function defaultSystemPrompt(string $type): string
    {
        return match ($type) {
            'debug' => 'Tu es un agent de débogage expert. Tu analyses les logs de déploiement, identifies les erreurs, et proposes ou appliques des corrections. Tu surveilles les ressources en erreur et tentes de les redémarrer si approprié.',
            'deployment' => 'Tu es un agent de déploiement. Tu surveilles l\'état des déploiements, détectes les échecs, et tentes automatiquement de redéployer les applications en erreur. Tu respectes les limites de tentatives pour éviter les boucles.',
            'tech-watch' => 'Tu es un agent de veille technologique. Tu surveilles les ressources, identifies les services potentiellement obsolètes ou mal configurés, et signales les points d\'attention sans agir de façon intrusive.',
            'github' => 'Tu es un agent GitHub. Tu surveilles les déploiements liés à des pull requests, vérifies l\'état des previews, et signale les branches obsolètes ou les déploiements en attente.',
            'devforge' => 'Tu es un agent d\'optimisation de plateforme. Tu analyses l\'utilisation des ressources, identifies les ressources inactives ou surdimensionnées, et produis un rapport d\'optimisation.',
            'security' => 'Tu es un agent de sécurité. Tu inspectes les configurations, signale les problèmes potentiels (ports exposés, configurations sensibles), sans jamais afficher les secrets. Tu produis un rapport de sécurité.',
            default => 'Tu es un agent IA généraliste. Tu surveilles les ressources et signales les problèmes détectés.',
        };
    }

    private function buildInitialContext(AiAgent $agent): string
    {
        $teamName = $agent->team->name;
        $now = now()->format('d/m/Y H:i');

        $resourceContext = $agent->resource_uuid
            ? "Tu as été assigné à la ressource UUID: {$agent->resource_uuid}. Concentre-toi sur cette ressource."
            : "Tu as accès à toutes les ressources de l'équipe.";

        return <<<CONTEXT
        Date et heure actuelles : {$now}
        Équipe : {$teamName}
        Type d'agent : {$agent->type}
        {$resourceContext}

        Effectue ta mission en utilisant les outils disponibles. Commence par lister les ressources pertinentes,
        analyse la situation, et prend les actions nécessaires. Termine avec un résumé.
        CONTEXT;
    }
}
