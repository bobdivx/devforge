<?php

namespace App\Services\DevForge;

use App\Models\Environment;
use App\Models\Project;
use App\Models\User;

class CurrentTeamResources
{
    public function __construct(private CurrentTeamContext $currentTeamContext) {}

    public function project(User $user, string $projectUuid): Project
    {
        $team = $this->currentTeamContext->resolve($user);

        return Project::query()
            ->where('team_id', $team->id)
            ->where('uuid', $projectUuid)
            ->firstOrFail();
    }

    public function environment(
        User $user,
        string $projectUuid,
        string $environmentUuid,
    ): Environment {
        return $this->project($user, $projectUuid)
            ->environments()
            ->where('uuid', $environmentUuid)
            ->firstOrFail();
    }
}
