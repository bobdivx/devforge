<?php

use App\Http\Controllers\DevForge\BootstrapController;
use App\Http\Controllers\DevForge\TeamController;
use Illuminate\Support\Facades\Route;

Route::get('/bootstrap', BootstrapController::class)->name('bootstrap');
Route::post('/teams/switch', [TeamController::class, 'switch'])->name('teams.switch');

require __DIR__.'/devforge-simple.php';
require __DIR__.'/devforge-core.php';
require __DIR__.'/devforge-realtime.php';
require __DIR__.'/devforge-agents.php';
